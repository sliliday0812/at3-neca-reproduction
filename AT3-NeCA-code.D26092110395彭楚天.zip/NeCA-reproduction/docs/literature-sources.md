# 文獻來源與查核紀錄

存取日期：**2026-10-28**。範圍為六篇已選論文的定向查核，未進行全領域窮盡搜尋；沒有以搜尋摘要替代原文方法及結果閱讀。文獻內容與實驗重跑證據分開處理，本子任務未啟動任何重建實驗。

## 來源優先次序與實際取得情形

| ID | 正式來源、用途 | 本次全文及證據狀態 |
|---|---|---|
| P1 NeCA | [PMC正式發表全文](https://pmc.ncbi.nlm.nih.gov/articles/PMC11673243/)；[PubMed PMID39768045](https://pubmed.ncbi.nlm.nih.gov/39768045/)；DOI10.3390/bioengineering11121227 | Europe PMC取得JATS XML，存在article body及六張table-wrap；以bundled jats_to_text讀取正文，再從JATS逐表檢查數值與數學標記。`evidence/neca.xml`為原始全文，`neca_readable.txt`為便讀衍生件；`neca.txt`是bundled parser的JSON格式結果，副檔名不代表純文字格式 |
| P2 3DGR-CAR | [MICCAI Society正式主會頁](https://papers.miccai.org/miccai-2024/005-Paper1015.html)；[官方PDF](https://papers.miccai.org/miccai-2024/paper/1015_paper.pdf)；DOI10.1007/978-3-031-72104-5_2 | 正式頁聲明開放版與錄取版內容一致。PDF10頁完整下載、解析；第6頁表1另渲染為PNG核對「New Projections」與「Volume」欄，防止把投影DSC寫成三維DSC |
| P3 DeepCA | [CVF正式PDF](https://openaccess.thecvf.com/content/WACV2025/papers/Wang_DeepCA_Deep_Learning-Based_3D_Coronary_Artery_Tree_Reconstruction_from_Two_WACV_2025_paper.pdf)；[Crossref DOI註冊資料](https://api.crossref.org/works/10.1109%2FWACV61041.2025.00043) | Web頁面403，但直接下載正式PDF成功（10頁）；Crossref回應status=ok、DOI/題名/四位作者/WACV/337–346頁一致，出版日期2025-02-26。閱讀§3.1/§4.1–4.3及表1，特別核實剛體模擬、配準與2D/3D指標 |
| P4 AutoCAR | [出版商](https://www.nature.com/articles/s42256-025-01025-7)；[作者項目頁](https://autocar.zyh.sh/)；[項目頁指向的官方庫](https://github.com/zhuyinheng/autocar_release) | 出版商網頁重導認證；curl取得HTML而非PDF，已保存為`autocar_download_block.html`，不算全文下載成功。重新閱讀本地既有原文轉錄：`既有AutoCAR原文轉錄檔XA3D_2025_AUTOCAR.txt`，複本`autocar_prior_fulltext.txt`保留PAGE標記。作者項目頁及代碼鏈接本次新核驗；本地轉錄不是新的實驗或新的出版商下載證據 |
| P5 SAX-NeRF | [CVF CVPR2024主會頁](https://openaccess.thecvf.com/content/CVPR2024/html/Cai_Structure-Aware_Sparse-View_X-ray_3D_Reconstruction_CVPR_2024_paper.html)；[正式PDF](https://openaccess.thecvf.com/content/CVPR2024/papers/Cai_Structure-Aware_Sparse-View_X-ray_3D_Reconstruction_CVPR_2024_paper.pdf) | 官方索引確認會議、作者、年分及11174–11183頁；PDF10頁完整下載解析。主實驗50訓練＋50新視角評估，第7頁表2為CT指標。DOI未核定，留空並使用正式網址，不猜填 |
| P6 R²-Gaussian | [NeurIPS正式主會記錄](https://proceedings.neurips.cc/paper_files/paper/2024/hash/4f550cb7b30b59553e50cd08a9dbf068-Abstract-Conference.html)；[正式PDF](https://proceedings.neurips.cc/paper_files/paper/2024/file/4f550cb7b30b59553e50cd08a9dbf068-Paper-Conference.pdf)；[作者arXiv v2](https://arxiv.org/html/2405.20693v2) | 正式頁明確標記Main Conference Track，提供DOI10.52202/079017-1427。PDF28頁完整下載解析；第7頁表1已渲染PNG核數。作者預印本HTML也已保存，屬輔助全文而非主會身分證據。表2區分2D/3D，附錄B列FIPS物體，附錄E列有限角度及標定限制 |

## 可重現查詢

1. 元資料定向查詢及來源發現：關鍵詞為`NeCA Neural Coronary Angiography Bioengineering 2024 Wang`、`3DGR-CAR MICCAI 2024 Gaussian reconstruction coronary`、`R2-Gaussian NeurIPS 2024 proceedings`、`SAX-NeRF CVPR 2024 openaccess`、`WACV2025 DeepCA Wang`、`AutoCAR s42256-025-01025-7`。最終方法和結果只依據上述原文／正式記錄。
2. NeCA全文API：`GET https://www.ebi.ac.uk/europepmc/webservices/rest/PMC11673243/fullTextXML`，無額外參數；非空body及table-wrap=6已檢查。只查既定PMCID，不做分頁。
3. DeepCA DOI API：`GET https://api.crossref.org/works/10.1109%2FWACV61041.2025.00043`，無額外參數；只讀單筆，檢查status、message、DOI、title和author，未把HTTP200當充分成功證據。
4. 正式PDF從表中各paper URL直接下載；本地PDF parser檢查頁數，關鍵表格依PDF頁／節定位。未調用需要API key的服務，也未保存任何個人憑證。
5. 原文正文／表格定位已整理在`structured_review.md`第6節；機器可讀欄位在`papers.json`，檔案大小和SHA256在`evidence_manifest.json`。

## 代碼來源與可重現性邊界

[NeCA](https://github.com/WangStephen/NeCA)、[3DGR-CAR](https://github.com/windrise/3DGR-CAR)、[DeepCA](https://github.com/WangStephen/DeepCA)、[AutoCAR](https://github.com/zhuyinheng/autocar_release)、[SAX-NeRF](https://github.com/caiyuanhao1998/SAX-NeRF)、[R²-Gaussian](https://github.com/Ruyi-Zha/r2_gaussian)均為論文或作者項目頁提供的代碼路徑。當前查核支持「有官方來源／倉庫」，不支持「完整實作已重跑成功」。

已有工程證據只用於比較邊界：`2026-10-08冠脈方法核驗歸檔method_cards.md`與`2026-10-08 NeCA核驗報告FINAL.md`。其中NeCA64³單例、套件差異和ODL角度問題均為2026-10-08既有報告；本子任務只讀，不重新證明其運行狀態。課程報告中新增的實驗結果應由主任務的新日誌和產物支撐。

## 仍有資料缺口

- AutoCAR出版商本次全文訪問受阻，故其數據／指標用既有原文轉錄，不宣稱新下載完整核驗；作者頁的正式題名、年分、作者、卷頁與DOI已新核。
- SAX-NeRF DOI留空，但正式CVF主會網址、題名、作者、年份、頁碼及全文均已核。
- 各冠脈資料的條目、患者、圖像與視角對數不可互換；未核定映射的地方保留「條目」。
- 本次未驗證所有官方庫的完整性、權重或可執行性，也未核定臨床可用性。沒有真實配對CTA–ICA三維真值；不將臨床再投影或對應誤差當成三維解剖誤差。
